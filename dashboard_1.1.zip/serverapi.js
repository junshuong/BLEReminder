const express = require('express')
const bodyParser = require('body-parser');
var mongo = require('mongodb').MongoClient;
var ObjectId = require('mongodb').ObjectID;
var url = "mongodb://127.0.0.1:27017/";

app = express();
const port = 3001;

// Configuring body parser middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.listen(port);

app.post('/Login', function (req, res) {
   const msg = req.body;
   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
	console.log(msg.UserID);
	console.log(msg.UserPassword);
    var myquery = { _userid: msg.UserID, _password: msg.UserPassword };
    dbo.collection("user_list").findOne(myquery)
    .then(userFound => {
    if (!userFound){
	  console.log("0 document retrieved");	
      return res.status(404).end();
    }
    console.log(JSON.stringify(userFound));
	return res.status(200).json({data: userFound});
    })
    .catch(err => console.log(err));
   });
});
app.post('/GetAllUsers', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    dbo.collection("user_list").find({}).toArray(function(err, result) {
		if (err) {
			console.log("0 document retrieved");	
			return res.status(404).end();
		}
		else
		{
		  console.log(JSON.stringify(result));
		  return res.status(200).json({data: result});
		}
    });
  });
});
app.post('/InsertUser', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myobj = { _userid: msg.UserID, _username: msg.UserName, _password: msg.UserPassword, _role: msg.UserRole };
    dbo.collection("user_list").insertOne(myobj, function(err, result) {
	  if (err) {
		console.log("0 document inserted");	
		return res.status(404).end();
	  }
	  else
	  {
	    console.log(JSON.stringify(result));
		return res.status(200).json({data: result});
	  }
	});
  });
});
app.post('/DeleteUser', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myobj = { _id: ObjectId(msg.ID) };
	console.log(msg.ID);
    dbo.collection("user_list").deleteOne(myobj, function(err, result) {
	  if (err) {
		console.log("0 document deleted");	
		return res.status(404).end();
	  }
	  else
	  {
	    console.log(JSON.stringify(result));
		return res.status(200).json({data: result});
	  }
	});
  });
});
app.post('/GetNotificationByUser', function (req, res) {
   const msg = req.body;
   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myquery = { _userid: msg.UserID };
    dbo.collection("notification").find({}, myquery).toArray(function(err, result) {
    if (err) {
		console.log("0 document retrieved");	
		return res.status(404).end();
	}
    else
	{
	  console.log(JSON.stringify(result));
	  return res.status(200).json({data: result});
	}
   });
  });
});
app.post('/GetAllNotifications', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    dbo.collection("notification").find({}).toArray(function(err, result) {
		if (err) {
			console.log("0 document retrieved");	
			return res.status(404).end();
		}
		else
		{
		  console.log(JSON.stringify(result));
		  return res.status(200).json({data: result});
		}
	});
  });
});
app.post('/InsertNotification', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myobj = { _notification_content: msg.NotificationContent, _location: msg.Location, _userid: msg.UserId };
    dbo.collection("notification").insertOne(myobj, function(err, result) {
	  if (err) {
		console.log("0 document inserted");	
		return res.status(404).end();
	  }
	  else
	  {
	    console.log(JSON.stringify(result));
		return res.status(200).json({data: result});
	  }
	});
  });
});
app.post('/DeleteNotification', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myobj = { _id: ObjectId(msg.ID) };
	console.log(msg.ID);
    dbo.collection("notification").deleteOne(myobj, function(err, result) {
	  if (err) {
		console.log("0 document deleted");	
		return res.status(404).end();
	  }
	  else
	  {
	    console.log(JSON.stringify(result));
		return res.status(200).json({data: result});
	  }
	});
  });
});
app.post('/GetAllBeacons', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    dbo.collection("beacon").find({}).toArray(function(err, result) {
		if (err) {
			console.log("0 document retrieved");	
			return res.status(404).end();
		}
		else
		{
		  console.log(JSON.stringify(result));
		  return res.status(200).json({data: result});
		}
	});
  });
});
app.post('/InsertBeacon', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myobj = { _mac_address: msg.MACAddress, _location: msg.Location };
    dbo.collection("beacon").insertOne(myobj, function(err, result) {
	  if (err) {
		console.log("0 document inserted");	
		return res.status(404).end();
	  }
	  else
	  {
	    console.log(JSON.stringify(result));
		return res.status(200).json({data: result});
	  }
	});
  });
});
app.post('/DeleteBeacon', function (req, res) {
   const msg = req.body;

   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    var myobj = { _id: ObjectId(msg.ID) };
	console.log(msg.ID);
    dbo.collection("beacon").deleteOne(myobj, function(err, result) {
	  if (err) {
		console.log("0 document deleted");	
		return res.status(404).end();
	  }
	  else
	  {
	    console.log(JSON.stringify(result));
		return res.status(200).json({data: result});
	  }
	});
  });
});
app.post('/GetMessageByLocationByUser', function (req, res) {
   const msg = req.body;
   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    console.log(msg.Location);
	console.log(msg.UserID);
	var myquery = { _location: msg.Location, _userid: msg.UserID };
   	dbo.collection("notification").findOne(myquery)
	.then(notificationFound => {
		if (!notificationFound){
		  console.log("0 document retrieved");	
		  return res.status(404).end();
		}
		console.log(JSON.stringify(notificationFound));
		return res.status(200).json({data: notificationFound});
		})
		.catch(err => console.log(err));
	   });
});
app.post('/GetBeaconByMACAddress', function (req, res) {
   const msg = req.body;
   mongo.connect(url, function(err, db) {
    if (err) throw err;
    var dbo = db.db("mydb");
    console.log(msg.MACAddress);
	var myquery = { _mac_address: msg.MACAddress };
	dbo.collection("beacon").findOne(myquery)
	.then(beaconFound => {
		if (!beaconFound){
		  console.log("0 document retrieved");	
		  return res.status(404).end();
		}
		console.log(JSON.stringify(beaconFound));
		return res.status(200).json({data: beaconFound});
		})
		.catch(err => console.log(err));
	});
});
console.log('todo list RESTful API server started on: ' + port);