$( document ).ready(function() {
document.getElementById("results").innerHTML = "Hello JavaScript!";
$("#btnClick1").click(function() {
  alert( "Handler for .click() called." );
});
$("#btnClick2").click(function() {
	$.ajax({
	  url: "test.html",
	  cache: false
	})
	  .done(function( html ) {
		$( "#results" ).append( html );
	});
});
});