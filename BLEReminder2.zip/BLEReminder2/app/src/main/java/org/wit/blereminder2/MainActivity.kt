package org.wit.blereminder2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import org.json.JSONObject
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // get reference to all views
        var et_user_name = findViewById(R.id.et_user_name) as EditText
        var et_password = findViewById(R.id.et_password) as EditText
        var btn_reset = findViewById(R.id.btn_reset) as Button
        var btn_submit = findViewById(R.id.btn_submit) as Button

        btn_reset.setOnClickListener {
            // clearing user_name and password edit text views on reset button click
            et_user_name.setText("")
            et_password.setText("")
        }
        // set on-click listener
        btn_submit.setOnClickListener {
        // simple dialog to show which user i.e.user01,02,03
            val user_name = et_user_name.text;
            val password = et_password.text;
//            Toast.makeText(this@MainActivity, et_user_name.text, Toast.LENGTH_LONG).show()

            // your code to validate the user_name and password combination
            // and verify the same
            if (et_user_name.text.toString() != "") {
                val url = "http://192.168.0.227:3001/login" // change to get notification by userID, also change port to 3001
                val jsonobj = JSONObject()
                jsonobj.put("UserID", et_user_name.text)
                jsonobj.put("UserPassword",et_password.text)

                val que = Volley.newRequestQueue(this)
                val req = JsonObjectRequest(
                    Request.Method.POST, url, jsonobj,
                    Response.Listener { response ->
                        if (response.has("data")) {
                            val data = response.getJSONObject("data")
                            val userid = data.getString("_userid")
                            if (userid == "") {
                                return@Listener
                            }
                        }
                    }, Response.ErrorListener {
                        Toast.makeText(this@MainActivity, et_user_name.text, Toast.LENGTH_LONG).show()
                        return@ErrorListener
                    })
                que.add(req)
            } else {
                return@setOnClickListener
            }
            // if login successful, proceed to Scanner Activity
            val intent = Intent(this, ScannerActivity::class.java)
            // start ScannerActivity
            startActivity(intent)
        }
    }
}

